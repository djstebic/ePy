'''
Created on May 15, 2017

@author: Blu3spirits & JuggernautAlpha
@version: 2.5
'''

import requests, re, csv, sys, eList, configparser, logging
from bs4 import BeautifulSoup
from pathlib import Path

class EList(object):
    def getFile(self, filename):
        userList = []
        with open(filename, 'r+') as f:
            [userList.append(x) for x in f]
        return userList

def getPage(self, url):
    page = requests.get(url).text
    soup = BeautifulSoup(page, "html.parser")
    return soup

def getTitle(self, soup):
    titleGen = (e.get_text() for e in soup.select('h1'))
    test = [x[16:] for x in titleGen]
    return test[0]
    
def getBid(soup):
    priceGen = (e.get_text() for e in soup.find_all(attrs={'id':'prcIsum'}))
    test = [x for x in priceGen]
    if test == []:
        priceGen = (e.get_text() for e in soup.find_all(attrs={'id':'prcIsum_bidPrice'}))
        test = [x for x in priceGen]
    return test[0]
def toFloat(string):
    try:
        price = float(string)
        return price
    except:
        pass

def writeToLog(title, price, link):
    with open('log.csv', 'a+', newline='') as cfile:
        writer = csv.writer(cfile, quotechar='|', quoting=csv.QUOTE_MINIMAL)
        writer.writerow((re.sub(',', '', title), price, link))

def applyParams(result, bannedArray, i, user_terms):
    p = re.compile(r'\s+')
    link = re.sub(p, '', ''.join([links.get('href') for links in result.select('a.vip')]))
    title = re.sub(p, '', ''.join([e.get_text() for e in result.select('a.vip')]))
    price = re.sub(p, '', ''.join([e.get_text() for e in result.select('span.bold')]))
    price = price[1:7]
    # Notification
        # Email
    # TODO: Effieciency (Free time when you're stuck on something)
        # No longer chain functions together. Run everything from the main.
    if "newlisting" in title.lower():
        pattern = re.compile('(\s*)Newlisting(\s*)')
        title = re.sub(pattern, '', title)
    if (any(key in title.lower() for key in bannedArray) or user_terms["search_term"] not in title):
        pass
    elif "Trendingat" in price:
        pattern = re.compile('(\s*)Trendingat(\s*)')
        price = toFloat((re.sub(pattern, '\\n\1Average\2', price)))
        if price == None:
            pass
        else:
            if price < user_terms['max_price']:
                writeToLog(title, (re.sub(pattern, '\\n\1Average\2', price)), link)
            else:
                i += 1
    else:
        price = toFloat(price)
        if price == None:
            pass
        else:
            if price < user_terms['max_price']:
                writeToLog(title, price, link)
            else:
                i += 1
    return i

def getPage(url, user_terms):
    page = requests.get(url).text
    soup = BeautifulSoup(page, "html.parser")
    idNum = []
    var = (e.get('id') for e in soup.find_all('li'))
    [idNum.append(x) for x in var if isinstance(x, str) and "item" in x]
    bannedArray = getBannedKeys()
    j = 0
    for i in range(len(idNum)):
        result = soup.find('li', attrs={"id":idNum[i]})
        j = (applyParams(result, bannedArray, j, user_terms))
        if j > 15:
            exit()

def getBannedKeys():
    bannedArray = []
    with open('banned_keywords.file', 'r') as f:
        [bannedArray.append((x.strip('\n'))) for x in f]
    return bannedArray

def getItems():
    items = []
    with open('itemlist.file', 'r') as f:
        [items.append(x.lower()) for x in f]
    return items

def main():
    logger = logging.getLogger()
    itemlist = getItems()
    config = configparser.ConfigParser()
    config.read('config.ini')
    user_terms = {
            'search_term':config['SETTINGS']['search_term'],
            'max_price':float(config['SETTINGS']['max_price'])
              }
    i = 2
    j = 50
    try:
        if sys.argv[1] != None:
            if sys.argv[1] == '-l' or sys.argv[1] == '--list':
                if Path(sys.argv[2]).is_file():
                    pass
                else:
                    logger.log(40, "User specified list not found, file created. Check current directory. You may have to refresh.")
                    open('mylist.txt', 'a+').close()
                    exit()
                list = eList.getFile(sys.argv[2])
                if list == []:
                    logger.error("Fatal: Please populate your personal list")
                    exit()
                else:
                    logger.log(30, "Starting list parsing. Depending on the list this could take a bit")
                    for x in list:
                        soup = eList.getPage(x)
                        title = eList.getTitle(soup)
                        price = eList.getBid(soup)
                        print("Title: %s\nCurrentBid: %s" % (title, price))
                    exit()
            elif sys.argv[1] == '-h' or sys.argv[1] == '--help':
                commands = '''Available commands:
    -l <filename> or --list <filename>
        This starts a subroutine that with the user specified list parses through the list and returns the title and price of their watchlist
    -h or --help
        This prints this dialogue
                '''
                print(commands)
                exit()
    except IndexError:
        logger.log(30, "No commands found, moving to default configurations and running")
        pass

    for url in itemlist:
        getPage(url, user_terms)
        baseurl = url
        while(True):
            if "ipg=" in url:
                pattern = re.compile(r'(\s*)1080&_ipg=50(\s*)')
            elif "ipg" not in url:
                pattern = re.compile(r'(\s*)1080&(\s*)')
            url = re.sub(pattern, ('1080&_pgn=%d&_skc=%d' % (i, j)), baseurl)
            getPage(url, user_terms)
            i += 1
            j += 50
if __name__ == '__main__':
    main()
